package application;

import javafx.animation.RotateTransition;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class SampleController {

    @FXML
    private Rectangle figura; 

    @FXML
    private Button btnGirar; 

    @FXML
    private Button btnParar; 

    private RotateTransition rotateTransition; 

    @FXML
    public void initialize() {
        
        rotateTransition = new RotateTransition(Duration.seconds(2), figura);
        rotateTransition.setByAngle(360); 
        rotateTransition.setCycleCount(RotateTransition.INDEFINITE); 

        
        btnGirar.setOnAction(e -> rotateTransition.play()); 
        btnParar.setOnAction(e -> rotateTransition.stop()); 
    }
}
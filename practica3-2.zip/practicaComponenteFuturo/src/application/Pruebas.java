package application;

import static org.junit.jupiter.api.Assertions.assertTrue;

import javafx.animation.RotateTransition;
import javafx.application.Platform;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class Pruebas {

    private static RotateTransition rotateTransition;
    private static Rectangle figura;

    @BeforeAll
    static void setUp() {
        Platform.startup(() -> {});

        figura = new Rectangle(100, 100);
        rotateTransition = new RotateTransition(Duration.seconds(2), figura);
        rotateTransition.setByAngle(360);
        rotateTransition.setCycleCount(RotateTransition.INDEFINITE);
    }

    @Test
    void testAngulo() throws InterruptedException {
        rotateTransition.play();

        Thread.sleep(500); 

        Platform.runLater(() -> rotateTransition.stop());

        Thread.sleep(100);

        double currentAngle = figura.getRotate();

        assertTrue(currentAngle <= 360, "El angulo no puede ser mayor a 360");
    }
}

